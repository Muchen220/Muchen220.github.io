<template>
    <div id="about">
        <h1>About Vue!</h1>
    </div>
</template>

<script>
    export default {
        name: "about"
    }
</script>

<style scoped>

</style>
